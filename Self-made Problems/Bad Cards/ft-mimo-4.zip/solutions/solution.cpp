#include<bits/stdc++.h>
using namespace std;
int main(){
    long long a, b;
    cin >> a >> b;
    cout << (a < b ? a : ((a-1)/(b-1))+a);
}